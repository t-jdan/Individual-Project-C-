Program should work as long as all needed files are in the same folder

Issues with node class resulting in errors for indirect flight

Program reads Input.txt file to find flights


Input.txt content should be in the format below:
StartCity,StartCountry
DestinationCity,DestinationCountry